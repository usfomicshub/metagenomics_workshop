if(!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("Maaslin2")

## load the pathway abundance file

abundances <- read.table('~/data/Metagenomics_workshop_USF/preterm_metagenomes_pathabundance.tsv', header=T, sep='\t', quote='', comment.char='')
colnames(abundances) <- sub('_.*','',colnames(abundances))

# remove the stratified rows (so we focus on total pathway abundance, not pathway abundance within particular species)
abundances_filt <- abundances[grep('|',abundances[,1],invert=T,fixed=T),]
rownames(abundances_filt) <- abundances_filt[,1]
abundances_filt <- abundances_filt[,-1]
##


## load the sample metadata and make sure the variables have the right types

meta <- read.table('~/data/Metagenomics_workshop_USF/meta_data_sra_acc.tsv', header=T, sep='\t')
rownames(meta) <- meta$Sample
# make sure the metadata table has samples in the same order as the abundances table
meta <- meta[colnames(abundances_filt),]
#
meta$Gender <- as.factor(meta$Gender)
# there are three factor levels for 'group', and it makes most biological sense to compare to the baseline of 'Term'
meta$Group <- relevel(as.factor(meta$Group), 'Term')
meta$Individual <- as.factor(meta$Individual)
meta$DeliveryMode <- as.factor(meta$DeliveryMode)
meta$EnteralFeeds_2mo <- as.factor(meta$EnteralFeeds_2mo)
# some values of 'Breastmilk' have extra spaces in them for some reason, so we'll clean those up
levels(meta$EnteralFeeds_2mo)[gsub(' ', '', levels(meta$EnteralFeeds_2mo)) == 'Breastmilk'] <- 'Breastmilk'

##


library(Maaslin2)

fit <- Maaslin2(abundances_filt, meta, '~/outputs/Metagenomics_workshop_USF/maaslin_functional', random_effects='Individual', fixed_effects=c('Gender','Group'), reference='Group,Term')