## requires beanplot, RColorBrewer, DESeq2, Seurat, and zinbwave
# install.packages(c('beanplot','RColorBrewer','Seurat'))
# if(!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager");
# BiocManager::install(c('DESeq2','zinbwave'))

## load the count data and rearrange it into a simple matrix

# without quote="", some lines break because the file has quotation characters within cells
counts_raw <- read.table('~/data/Metagenomics_workshop_USF/kaiju_species.tsv',header=T,sep='\t',quote="")
# clean up sample names but stripping all the extra info off of them
counts_raw[,1] <- gsub('_kaiju.*','',gsub('.*/','',counts_raw[,1]))
# transform the data from long format to wide
counts <- reshape(counts_raw, idvar='taxon_id', timevar='file', v.names='reads', direction='wide', drop=c('percent','taxon_name'))
# sample/taxon combinations that had no data in the original long format get NA's in the wide matrix. These are actually zeros, so let's change those
counts[is.na(counts)] <- 0
# make sure the taxon IDs look like character vectors by adding text, just to be safe, and make these rownames
rownames(counts) <- paste0('taxon_id_',counts[,1])
# get rid of the taxon ids from the actual data of the matrix
counts <- counts[,-1]
# clean up the sample names again
colnames(counts) <- sub('reads.','',colnames(counts))
# tell R that the data are all uniformly numeric rather than treating each column as an independent factor
counts <- as.matrix(counts)
# filter out taxa that are extremely rare
counts <- counts[apply(counts,1,function(x) sum(x>5)>5),]

##

## load the sample metadata and make sure the variables have the right types

meta <- read.table('~/data/Metagenomics_workshop_USF/meta_data_sra_acc.tsv', header=T, sep='\t')
rownames(meta) <- meta$Sample
# make sure the metadata table has samples in the same order as the counts table
meta <- meta[colnames(counts),]
#
meta$Gender <- as.factor(meta$Gender)
# there are three factor levels for 'group', and it makes most biological sense to compare to the baseline of 'Term'
meta$Group <- relevel(as.factor(meta$Group), 'Term')
meta$Individual <- as.factor(meta$Individual)
meta$DeliveryMode <- as.factor(meta$DeliveryMode)
meta$EnteralFeeds_2mo <- as.factor(meta$EnteralFeeds_2mo)
# some values of 'Breastmilk' have extra spaces in them for some reason, so we'll clean those up
levels(meta$EnteralFeeds_2mo)[gsub(' ', '', levels(meta$EnteralFeeds_2mo)) == 'Breastmilk'] <- 'Breastmilk'

##

## infer latent variables and the difference between biological and artifactual zeros using ZINB-WaVE

library(zinbwave)
# gather our counts and our metadata into a single object which zinbwave uses
zi <- SummarizedExperiment(assays = SimpleList(counts = counts), colData = meta)
# Gender and Group are 'interesting' variables whose effects we want to test, while Individual is a blocking variable that we want to control for
# K = 5 refers to the number of latent variables that we want to infer. I would probably try more but it takes longer
# observationalWeights = TRUE is important for being able to transfer our bio/artifactual zero inference to the subsequent differential abundance analysis
# epsilon=1e12 is recommended for using these results with DESeq2 - can't remember why right now!
zi <- zinbwave(zi, K = 5, X = ~ Gender + Group + Individual, observationalWeights = TRUE, epsilon=1e12)
# extract latent variables from model fit
W <- reducedDim(zi)
# plot first two latent variables, see if they correspond to any of the sample factors that we left out of the model
plot(W[,1:2], col=c('red','blue')[meta$DeliveryMode])
# plot another sample factor - this one is more complicated to set colors because it has more than two levels
factorcolors <- RColorBrewer::brewer.pal(5, "Set1")
plot(W, col = factorcolors[meta$EnteralFeeds_2mo])

##

## convert zinbwave's numeric latent variables into categorical clusters using Seurat (very optional, may depend on plotting of previous results)

library(Seurat)
# convert the data object that zinbwave used and modified into a Seurat object, which is needed for this library
seu <- as.Seurat(x=zi, counts = 'counts', data = 'counts')
# interpret linear effects from zinbwave as embeddings of truly nonlinear relationships, further reducing dimensionality and potentially helping with clustering
seu <- RunUMAP(seu, dims = 1:ncol(W), reduction = 'zinbwave', n.components = 2)
# identify clusters. play with parameters to find more or less clusters - or maybe if it's obvious from plots, just manually define clusters instead
seu <- FindNeighbors(seu, reduction = "umap", dims = 1:2)
seu <- FindClusters(object = seu)
# save clusters as a new factor
clusts <- as.factor(seu$seurat_clusters)
# plot zinbwave variables, but this time with empirical cluster coloring
factorcolors <- RColorBrewer::brewer.pal(9, "Set1")
plot(W[,1:2],col=factorcolors[clusts])
# extract UMAP nonlinear coordinates
W2 <- Embeddings(seu$umap)
# plot nonlinear UMAP coordinates with the clusters that were found using them
factorcolors <- RColorBrewer::brewer.pal(9, "Set1")
plot(W2,col=factorcolors[clusts])
# add clusters to metadata object
colData(zi) <- cbind(colData(zi), clusts)

##

## differential abundance analysis

library(DESeq2)
# convert zinbwave-modified object, containing observation weights, into a DESeqDataSet object
# define design formula that is as full as possible without creating less-than-full-rank model matrix (e.g. Individual, which is nested within both Gender and Group, can't be included :( ))
deseq_object <- DESeqDataSet(zi, design = ~ Gender + Group + clusts)
# fit deseq2 models
# LRT = likelihood ratio test, which is highly recommended if possible. Requires a 'reduced' model to compare to the full model specified above;this reduced model must be fit separately for every factor you want to test
# poscounts is necessary for most metagenomics datasets, which are likely to have at least one zero count in every sample.
# minmu and minReplicates are also set to values appropriatae for metagenomics datasets (defaults are for transcriptomics, which has slightly different statistical properties)
# useT makes the model more robust to outliers
# fit a model to test for the overall effect of Group, while controling for Gender and the correlation induced by the empirical clusters
res_group <- DESeq(deseq_object, test='LRT', sfType='poscounts', reduced = ~ Gender + clusts, useT=TRUE, minmu=1e-6, minReplicatesForReplace=Inf)
# extract the results
ps_group <- results(res_group)
# sort the results by deviation from the null expectation
ps_group <- ps_group[order(ps_group[,'padj']),]
# let's just look at the distribution of the most significant taxon
topdiff <- rownames(ps_group)[[1]]

# first we need to make our data easier for our human brains to understand, by converting to relative abundance
relabund <- apply(counts,2,function(x) x/sum(x))
# combine these values with our metadata for easier plotting
merged_rel <- cbind(colData(zi),t(relabund))

# now lets just try a simple boxplot
boxplot(as.formula(paste0(topdiff,' ~ Group')), merged_rel)

# not very easy on the eyes. it often makes more sense to consider abundances on the log scale, which is in fact how we modeled them
# first we have to get rid of those pesky 0's, which become infinite when log-transformed
relabund_0na <- relabund
relabund_0na[relabund_0na==0] <- NA
merged_rel_0na <- cbind(meta,t(relabund_0na))
# now a boxplot on the log scale
boxplot(as.formula(paste0(topdiff,' ~ Group')), merged_rel_0na, log='y')

# I prefer the extra information communicated with beanplots
# a couple extra parameters here just make the labels easier to read
beanplot::beanplot(as.formula(paste0(topdiff,' ~ Group')), merged_rel_0na, log='y', las=2, cex.axis=0.5)
# before we've tested for the effects, lets see if our Group results interact with Gender
beanplot::beanplot(as.formula(paste0(topdiff,' ~ Gender + Group')), merged_rel_0na, log='y', las=2, cex.axis=0.5)

# what is this taxon, anyway?
counts_raw$taxon_name[counts_raw$taxon_id == sub('taxon_id_','',topdiff)]

# now let's fit a model to test for the effect of Gender, while controling for Group and the correlation induced by the empirical clusters
# all steps are the same as above, reusing some of the objects we already created
res_gender <- DESeq(deseq_object, test='LRT', sfType='poscounts', reduced = ~ Group + clusts, useT=TRUE, minmu=1e-6, minReplicatesForReplace=Inf)
ps_gender <- results(res_gender)
ps_gender <- ps_gender[order(ps_gender[,'padj']),]
topdiff <- rownames(ps_gender)[[1]]
beanplot::beanplot(as.formula(paste0(topdiff,' ~ Gender')), merged_rel_0na, log='y', las=2, cex.axis=0.5)
#
beanplot::beanplot(as.formula(paste0(topdiff,' ~ Group + Gender')), merged_rel_0na, log='y', las=2, cex.axis=0.5)
# what is this taxon?
counts_raw$taxon_name[counts_raw$taxon_id == sub('taxon_id_','',topdiff)]



# let's try to control for Individual effects. DESeq doesn't make this easy (read the vignette on 'Model Matrix not full rank')
# first we have to re-code Individual as a factor 'nested' within whatever factor we want to test (in this case Group)
ind_group <- rep('',nrow(colData(zi)))
for(g in unique(colData(zi)$Group)) {
  i <- 1
  for(h in unique(colData(zi)$Individual[colData(zi)$Group==g])) {
    ind_group[colData(zi)$Group == g & colData(zi)$Individual == h] <- i
    i <- i + 1
  }
}
ind_group <- as.factor(ind_group)
# compare this new variable to the old one
head(cbind(colData(zi)$Group,colData(zi)$Individual,ind_group))
# add the newly coded factor to the metadata table
colData(zi) <- cbind(colData(zi),ind_group)
# we have to provide a custom model matrix, not just a formula. We can't control for Gender at the same time as Individual because the model matrix becomes reduced rank :(
mm <- model.matrix(~ Group + Group:ind_group, data=colData(zi))
# the model.matrix function isn't very smart, and produces some factors that have no representative samples. so we have to remove those columns. (and add the intercept back in)
mm <- cbind(1,mm[,apply(mm,2,function(x) sd(x) > 0)])
# create our DESeq object freshly from the zinbwave results
deseq_object <- DESeqDataSet(zi, design = mm)
# fit the model. Due to quirks of DESeq, it's impossible to use the preferred likelihood ratio test :(, so we don't need to provide a reduced model
res_group_cont <- DESeq(deseq_object, sfType='poscounts', useT=TRUE, minmu=1e-6, minReplicatesForReplace=Inf)
# when using a Wald test of significance, it's best to 'shrink' estimates to be more conservative using this function
# you must specify a single column of the model matrix. In this case, we made 'Group:Term' the base level for this factor, so we are specifically contrasting Preterm antibiotics to Term (and ignoring the third level, Preterms with some later antibiotics)
ps_group_cont <- lfcShrink(res_group_cont, coef="GroupEarly.only.abx", type = "normal")
# order the results, as before
ps <- ps_group_cont[order(ps_group_cont[,'padj']),]
# select the top taxon, as before
topdiff <- rownames(ps)[[1]]
# plot as before. is this more convincing, less, no different?
beanplot::beanplot(as.formula(paste0(topdiff,' ~ Group + Gender')), merged_rel_0na, log='y', las=2, cex.axis=0.5)
# what is this taxon?
counts_raw$taxon_name[counts_raw$taxon_id == sub('taxon_id_','',topdiff)]


## save our session so we can return to it later
save.image(file = '~/outputs/Metagenomics_workshop_USF/res_deseq_tax_20210726.RData')
